import "./App.css";
function App(){
    return <div className="App">Firebase Course</div>
}
export default App;